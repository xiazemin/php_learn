<?php
function show(){
    echo "l am show()";
}
